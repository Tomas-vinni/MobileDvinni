package dvinni.mob

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


data class Chat(val senderName: String, val lastMessage: String, val timestamp: String)

class ChatAdapter(private val chatList: List<Chat>) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameTextView: TextView = view.findViewById(R.id.chat_name)
        val messageTextView: TextView = view.findViewById(R.id.chat_message)
        val timeTextView: TextView = view.findViewById(R.id.chat_time)

        init {
            // Установка обработки кликов, если необходимо
            itemView.setOnClickListener {
                // Логика перехода на экран чата
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.chat_item, parent, false)
        return ChatViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val chat = chatList[position]
        holder.nameTextView.text = chat.senderName
        holder.messageTextView.text = chat.lastMessage
        holder.timeTextView.text = chat.timestamp
    }

    override fun getItemCount() = chatList.size
}
