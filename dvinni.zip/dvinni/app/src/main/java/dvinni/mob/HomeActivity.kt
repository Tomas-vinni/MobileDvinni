package dvinni.mob

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dvinni.mob.ChatAdapter as DvinniMobChatAdapter


class HomeActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        recyclerView = findViewById(R.id.chat_recycler_view)

        // Создание фиктивных данных для чатов
        val chatList = listOf(
            Chat("Иван", "Привет!", "10 мин назад"),
            Chat("Анна", "Как дела?", "15 мин назад"),
            Chat("Сергей", "Увидимся позже", "30 мин назад")
            // Добавьте больше фиктивных данных по необходимости
        )

        recyclerView.layoutManager = LinearLayoutManager(this)

        val adapter = DvinniMobChatAdapter(chatList)

        recyclerView.adapter = adapter
    }
}

